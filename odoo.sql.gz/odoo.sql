--
-- PostgreSQL database dump
--

\restrict D6Ey7wzsqt4FjsP9jaOr8c4p5Tvk9BTpZDqjj6Z0ck59OevOI5Y8UGDcKG2IFXQ

-- Dumped from database version 13.23 (Debian 13.23-1.pgdg13+1)
-- Dumped by pg_dump version 13.23 (Debian 13.23-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict D6Ey7wzsqt4FjsP9jaOr8c4p5Tvk9BTpZDqjj6Z0ck59OevOI5Y8UGDcKG2IFXQ

