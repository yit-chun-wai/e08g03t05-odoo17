--
-- PostgreSQL database dump
--

\restrict 8MNYbNJkEKcp069Zk17UHMiLcIyjJExZKbL2nBhcFDtcZnjt6ntO7k5pyUn2B9E

-- Dumped from database version 13.23 (Debian 13.23-1.pgdg13+1)
-- Dumped by pg_dump version 13.23 (Debian 13.23-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict 8MNYbNJkEKcp069Zk17UHMiLcIyjJExZKbL2nBhcFDtcZnjt6ntO7k5pyUn2B9E

